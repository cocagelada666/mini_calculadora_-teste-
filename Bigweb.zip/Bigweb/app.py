import os
import logging
from flask import Flask, request, render_template, send_file, flash, redirect, url_for, jsonify, session
import requests
from bs4 import BeautifulSoup
import shutil
import zipfile
from urllib.parse import urljoin, urlparse
import tempfile
import uuid
from werkzeug.middleware.proxy_fix import ProxyFix
from osint_tools import OSINTAnalyzer
import json
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from models import db, User, Badge, Investigation, ImageScrapeJob, init_badges
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.DEBUG)

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "fallback-secret-key")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Database configuration
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get("DATABASE_URL")
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
    'pool_pre_ping': True,
    'pool_recycle': 300,
}

# Initialize extensions
db.init_app(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Faça login para acessar esta página.'
login_manager.login_message_category = 'info'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Create downloads directory if it doesn't exist
DOWNLOADS_DIR = 'downloads'
if not os.path.exists(DOWNLOADS_DIR):
    os.makedirs(DOWNLOADS_DIR)

# Initialize OSINT analyzer
osint = OSINTAnalyzer()

# Initialize database
with app.app_context():
    db.create_all()
    init_badges()

def update_user_stats(user, investigation_type, **kwargs):
    """Update user statistics and check for badges"""
    user.total_investigations += 1
    user.add_experience(10)  # Base XP for any investigation
    
    if investigation_type == 'domain':
        user.total_domains_analyzed += 1
        user.add_experience(5)  # Extra XP for domain analysis
    elif investigation_type == 'url':
        user.total_urls_analyzed += 1
        user.add_experience(5)
    elif investigation_type == 'portscan':
        user.total_ports_scanned += kwargs.get('ports_scanned', 1)
        user.add_experience(15)  # More XP for port scanning
    elif investigation_type == 'image_scrape':
        images_count = kwargs.get('images_count', 0)
        user.total_images_scraped += images_count
        user.add_experience(images_count * 2)  # 2 XP per image
    
    # Check for new badges
    new_badges = user.check_badges()
    
    # Update last activity
    user.last_login = datetime.utcnow()
    
    db.session.commit()
    
    return new_badges

def is_valid_url(url):
    """Validate if the URL is properly formatted"""
    try:
        result = urlparse(url)
        return all([result.scheme, result.netloc]) and result.scheme in ['http', 'https']
    except:
        return False

def is_image_url(url):
    """Check if URL points to an image based on file extension"""
    try:
        parsed = urlparse(url)
        path = parsed.path.lower()
        # Remove query parameters
        path = path.split('?')[0]
        return any(path.endswith(ext) for ext in ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.svg'])
    except:
        return False

def download_image(img_url, folder, index):
    """Download a single image and save it to the folder"""
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        response = requests.get(img_url, timeout=10, headers=headers)
        response.raise_for_status()
        
        # Get file extension from URL
        parsed_url = urlparse(img_url)
        ext = os.path.splitext(parsed_url.path)[1].lower()
        
        # If no extension or invalid extension, try to guess from content-type
        if not ext or ext not in ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.svg']:
            content_type = response.headers.get('content-type', '').lower()
            if 'jpeg' in content_type or 'jpg' in content_type:
                ext = '.jpg'
            elif 'png' in content_type:
                ext = '.png'
            elif 'gif' in content_type:
                ext = '.gif'
            elif 'webp' in content_type:
                ext = '.webp'
            elif 'bmp' in content_type:
                ext = '.bmp'
            elif 'svg' in content_type:
                ext = '.svg'
            else:
                ext = '.jpg'  # default fallback
        
        # Create filename
        filename = f'imagem_{index:03d}{ext}'
        filepath = os.path.join(folder, filename)
        
        # Save the image
        with open(filepath, 'wb') as f:
            f.write(response.content)
        
        return True
    except Exception as e:
        logging.error(f"Failed to download image {img_url}: {str(e)}")
        return False

def scrape_images(url):
    """Scrape images from the given URL"""
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        response = requests.get(url, timeout=15, headers=headers)
        response.raise_for_status()
        
        soup = BeautifulSoup(response.content, 'html.parser')
        images = soup.find_all('img')
        
        image_urls = set()
        
        for img in images:
            src = img.get('src')
            if not src:
                continue
                
            # Convert relative URLs to absolute URLs
            full_url = urljoin(url, src)
            
            # Validate URL
            if not is_valid_url(full_url):
                continue
                
            image_urls.add(full_url)
        
        return list(image_urls)
    except Exception as e:
        logging.error(f"Failed to scrape images from {url}: {str(e)}")
        raise

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.query.filter_by(username=username).first()
        
        if user and user.check_password(password):
            login_user(user)
            user.last_login = datetime.utcnow()
            db.session.commit()
            flash('Login realizado com sucesso!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Nome de usuário ou senha incorretos.', 'danger')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        
        if User.query.filter_by(username=username).first():
            flash('Nome de usuário já existe.', 'danger')
        elif User.query.filter_by(email=email).first():
            flash('Email já está em uso.', 'danger')
        else:
            # Check if this is the first user (make them admin)
            is_first_user = User.query.count() == 0
            
            user = User(username=username, email=email)
            user.set_password(password)
            
            if is_first_user:
                user.is_admin = True
                flash('Conta criada com sucesso! Você é o primeiro usuário e foi definido como administrador.', 'success')
            else:
                flash('Conta criada com sucesso!', 'success')
            
            db.session.add(user)
            db.session.commit()
            
            login_user(user)
            return redirect(url_for('dashboard'))
    
    return render_template('register.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Logout realizado com sucesso!', 'success')
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    recent_investigations = Investigation.query.filter_by(user_id=current_user.id).order_by(Investigation.created_at.desc()).limit(5).all()
    recent_images = ImageScrapeJob.query.filter_by(user_id=current_user.id).order_by(ImageScrapeJob.created_at.desc()).limit(5).all()
    
    return render_template('dashboard.html', 
                         user=current_user,
                         recent_investigations=recent_investigations,
                         recent_images=recent_images)

@app.route('/profile')
@login_required
def profile():
    return render_template('profile.html', user=current_user)

@app.route('/profile/edit', methods=['GET', 'POST'])
@login_required
def edit_profile():
    if request.method == 'POST':
        current_user.display_name = request.form.get('display_name')
        current_user.bio = request.form.get('bio')
        current_user.location = request.form.get('location')
        current_user.website = request.form.get('website')
        db.session.commit()
        flash('Perfil atualizado com sucesso!', 'success')
        return redirect(url_for('profile'))
    
    return render_template('edit_profile.html', user=current_user)

@app.route('/leaderboard')
def leaderboard():
    top_users = User.query.order_by(User.level.desc(), User.experience_points.desc()).limit(20).all()
    return render_template('leaderboard.html', users=top_users)

@app.route('/admin')
@login_required
def admin_panel():
    if not current_user.is_admin:
        flash('Acesso negado. Apenas administradores podem acessar esta página.', 'danger')
        return redirect(url_for('dashboard'))
    
    total_users = User.query.count()
    total_badges = Badge.query.count()
    total_investigations = Investigation.query.count()
    recent_users = User.query.order_by(User.created_at.desc()).limit(10).all()
    
    return render_template('admin_panel.html', 
                         total_users=total_users,
                         total_badges=total_badges,
                         total_investigations=total_investigations,
                         recent_users=recent_users)

@app.route('/admin/badges')
@login_required
def admin_badges():
    if not current_user.is_admin:
        flash('Acesso negado. Apenas administradores podem acessar esta página.', 'danger')
        return redirect(url_for('dashboard'))
    
    badges = Badge.query.all()
    return render_template('admin_badges.html', badges=badges)

@app.route('/admin/badge/create', methods=['GET', 'POST'])
@login_required
def admin_create_badge():
    if not current_user.is_admin:
        flash('Acesso negado. Apenas administradores podem acessar esta página.', 'danger')
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        name = request.form.get('name')
        title = request.form.get('title')
        description = request.form.get('description')
        icon = request.form.get('icon')
        color = request.form.get('color')
        rarity = request.form.get('rarity')
        
        if Badge.query.filter_by(name=name).first():
            flash('Badge com este nome já existe.', 'danger')
        else:
            badge = Badge(
                name=name,
                title=title,
                description=description,
                icon=icon,
                color=color,
                rarity=rarity
            )
            db.session.add(badge)
            db.session.commit()
            flash('Badge criado com sucesso!', 'success')
            return redirect(url_for('admin_badges'))
    
    return render_template('admin_create_badge.html')

@app.route('/admin/badge/<int:badge_id>/edit', methods=['GET', 'POST'])
@login_required
def admin_edit_badge(badge_id):
    if not current_user.is_admin:
        flash('Acesso negado. Apenas administradores podem acessar esta página.', 'danger')
        return redirect(url_for('dashboard'))
    
    badge = Badge.query.get_or_404(badge_id)
    
    if request.method == 'POST':
        badge.name = request.form.get('name')
        badge.title = request.form.get('title')
        badge.description = request.form.get('description')
        badge.icon = request.form.get('icon')
        badge.color = request.form.get('color')
        badge.rarity = request.form.get('rarity')
        
        db.session.commit()
        flash('Badge atualizado com sucesso!', 'success')
        return redirect(url_for('admin_badges'))
    
    return render_template('admin_edit_badge.html', badge=badge)

@app.route('/admin/badge/<int:badge_id>/delete', methods=['POST'])
@login_required
def admin_delete_badge(badge_id):
    if not current_user.is_admin:
        flash('Acesso negado. Apenas administradores podem acessar esta página.', 'danger')
        return redirect(url_for('dashboard'))
    
    badge = Badge.query.get_or_404(badge_id)
    db.session.delete(badge)
    db.session.commit()
    flash('Badge deletado com sucesso!', 'success')
    return redirect(url_for('admin_badges'))

@app.route('/admin/user/<int:user_id>/toggle_admin', methods=['POST'])
@login_required
def admin_toggle_user_admin(user_id):
    if not current_user.is_admin:
        flash('Acesso negado. Apenas administradores podem acessar esta página.', 'danger')
        return redirect(url_for('dashboard'))
    
    user = User.query.get_or_404(user_id)
    user.is_admin = not user.is_admin
    db.session.commit()
    
    status = 'administrador' if user.is_admin else 'usuário comum'
    flash(f'Usuário {user.username} agora é {status}.', 'success')
    return redirect(url_for('admin_panel'))

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        url = request.form.get('url', '').strip()
        
        if not url:
            flash('Por favor, insira uma URL válida.', 'danger')
            return redirect(url_for('index'))
        
        if not is_valid_url(url):
            flash('URL inválida. Certifique-se de que começa com http:// ou https://', 'danger')
            return redirect(url_for('index'))
        
        try:
            # Scrape images from the URL
            flash('Buscando imagens na página...', 'info')
            image_urls = scrape_images(url)
            
            if not image_urls:
                flash('Nenhuma imagem encontrada nesta página.', 'warning')
                return redirect(url_for('index'))
            
            # Create temporary directory for this session
            session_id = str(uuid.uuid4())
            temp_dir = os.path.join(tempfile.gettempdir(), f'image_scraper_{session_id}')
            os.makedirs(temp_dir, exist_ok=True)
            
            # Download images
            flash(f'Encontradas {len(image_urls)} imagens. Fazendo download...', 'info')
            downloaded_count = 0
            
            for i, img_url in enumerate(image_urls, 1):
                if download_image(img_url, temp_dir, i):
                    downloaded_count += 1
            
            if downloaded_count == 0:
                flash('Não foi possível fazer download de nenhuma imagem.', 'danger')
                shutil.rmtree(temp_dir, ignore_errors=True)
                return redirect(url_for('index'))
            
            # Create ZIP file
            zip_filename = f'imagens_{session_id}.zip'
            zip_path = os.path.join(DOWNLOADS_DIR, zip_filename)
            
            with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for root, dirs, files in os.walk(temp_dir):
                    for file in files:
                        file_path = os.path.join(root, file)
                        arcname = os.path.relpath(file_path, temp_dir)
                        zipf.write(file_path, arcname)
            
            # Clean up temporary directory
            shutil.rmtree(temp_dir, ignore_errors=True)
            
            # Update user stats if logged in
            if current_user.is_authenticated:
                new_badges = update_user_stats(current_user, 'image_scrape', images_count=downloaded_count)
                
                # Save image scrape job
                job = ImageScrapeJob(
                    user_id=current_user.id,
                    url=url,
                    images_found=len(image_urls),
                    images_downloaded=downloaded_count,
                    zip_filename=zip_filename,
                    status='completed'
                )
                db.session.add(job)
                db.session.commit()
                
                # Show badge notifications
                for badge_name in new_badges:
                    badge = Badge.query.filter_by(name=badge_name).first()
                    if badge:
                        flash(f'🎉 Badge desbloqueado: {badge.title}!', 'success')
            
            flash(f'Sucesso! {downloaded_count} imagens foram empacotadas em um arquivo ZIP.', 'success')
            return render_template('index.html', zip_filename=zip_filename, downloaded_count=downloaded_count)
            
        except Exception as e:
            flash(f'Erro ao processar a página: {str(e)}', 'danger')
            return redirect(url_for('index'))
    
    return render_template('index.html')

@app.route('/download/<filename>')
def download_file(filename):
    """Download the generated ZIP file"""
    try:
        file_path = os.path.join(DOWNLOADS_DIR, filename)
        if os.path.exists(file_path):
            return send_file(file_path, as_attachment=True, download_name='imagens.zip')
        else:
            flash('Arquivo não encontrado.', 'danger')
            return redirect(url_for('index'))
    except Exception as e:
        flash(f'Erro ao fazer download: {str(e)}', 'danger')
        return redirect(url_for('index'))

@app.route('/cleanup')
def cleanup():
    """Clean up old ZIP files"""
    try:
        for filename in os.listdir(DOWNLOADS_DIR):
            file_path = os.path.join(DOWNLOADS_DIR, filename)
            if os.path.isfile(file_path):
                os.remove(file_path)
        flash('Arquivos limpos com sucesso.', 'success')
    except Exception as e:
        flash(f'Erro na limpeza: {str(e)}', 'danger')
    
    return redirect(url_for('index'))

@app.route('/osint')
def osint_page():
    """OSINT tools page"""
    return render_template('osint.html')

@app.route('/osint/domain', methods=['POST'])
@login_required
def osint_domain():
    """Analyze domain using OSINT tools"""
    try:
        domain = request.form.get('domain', '').strip()
        if not domain:
            return jsonify({'error': 'Domínio não fornecido'}), 400
        
        # Remove protocol if present
        if domain.startswith('http://') or domain.startswith('https://'):
            domain = urlparse(domain).netloc
        
        results = osint.analyze_domain(domain)
        
        # Save investigation
        investigation = Investigation(
            user_id=current_user.id,
            type='domain',
            target=domain,
            status='completed' if 'error' not in results else 'failed'
        )
        investigation.set_results(results)
        db.session.add(investigation)
        
        # Update user stats
        if 'error' not in results:
            new_badges = update_user_stats(current_user, 'domain')
            results['new_badges'] = new_badges
        
        return jsonify(results)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/osint/url', methods=['POST'])
@login_required
def osint_url():
    """Analyze URL using OSINT tools"""
    try:
        url = request.form.get('url', '').strip()
        if not url:
            return jsonify({'error': 'URL não fornecida'}), 400
        
        results = osint.analyze_url(url)
        
        # Save investigation
        investigation = Investigation(
            user_id=current_user.id,
            type='url',
            target=url,
            status='completed' if 'error' not in results else 'failed'
        )
        investigation.set_results(results)
        db.session.add(investigation)
        
        # Update user stats
        if 'error' not in results:
            new_badges = update_user_stats(current_user, 'url')
            results['new_badges'] = new_badges
        
        return jsonify(results)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/osint/ip', methods=['POST'])
@login_required
def osint_ip():
    """Analyze IP address using OSINT tools"""
    try:
        ip = request.form.get('ip', '').strip()
        if not ip:
            return jsonify({'error': 'IP não fornecido'}), 400
        
        results = osint._get_ip_info(ip)
        
        # Save investigation
        investigation = Investigation(
            user_id=current_user.id,
            type='ip',
            target=ip,
            status='completed' if 'error' not in results else 'failed'
        )
        investigation.set_results(results)
        db.session.add(investigation)
        
        # Update user stats
        if 'error' not in results:
            new_badges = update_user_stats(current_user, 'ip')
            results['new_badges'] = new_badges
        
        return jsonify(results)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/osint/phone', methods=['POST'])
@login_required
def osint_phone():
    """Analyze phone number using OSINT tools"""
    try:
        phone = request.form.get('phone', '').strip()
        country = request.form.get('country', 'BR').strip()
        
        if not phone:
            return jsonify({'error': 'Número de telefone não fornecido'}), 400
        
        results = osint.analyze_phone(phone, country)
        
        # Save investigation
        investigation = Investigation(
            user_id=current_user.id,
            type='phone',
            target=phone,
            status='completed' if 'error' not in results else 'failed'
        )
        investigation.set_results(results)
        db.session.add(investigation)
        
        # Update user stats
        if 'error' not in results:
            new_badges = update_user_stats(current_user, 'phone')
            results['new_badges'] = new_badges
        
        return jsonify(results)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/osint/email', methods=['POST'])
@login_required
def osint_email():
    """Analyze email using OSINT tools"""
    try:
        email = request.form.get('email', '').strip()
        if not email:
            return jsonify({'error': 'Email não fornecido'}), 400
        
        results = osint.analyze_email(email)
        
        # Save investigation
        investigation = Investigation(
            user_id=current_user.id,
            type='email',
            target=email,
            status='completed' if 'error' not in results else 'failed'
        )
        investigation.set_results(results)
        db.session.add(investigation)
        
        # Update user stats
        if 'error' not in results:
            new_badges = update_user_stats(current_user, 'email')
            results['new_badges'] = new_badges
        
        return jsonify(results)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/osint/portscan', methods=['POST'])
@login_required
def osint_portscan():
    """Perform port scan using OSINT tools"""
    try:
        host = request.form.get('host', '').strip()
        ports = request.form.get('ports', '22,23,21,20,80,443,8080,8443,8888,3389,5432,3306,1433,5672,6379,9200,9300').strip()
        
        if not host:
            return jsonify({'error': 'Host não fornecido'}), 400
        
        results = osint.port_scan(host, ports)
        
        # Save investigation
        investigation = Investigation(
            user_id=current_user.id,
            type='portscan',
            target=host,
            status='completed' if 'error' not in results else 'failed'
        )
        investigation.set_results(results)
        db.session.add(investigation)
        
        # Update user stats
        if 'error' not in results:
            ports_count = len(ports.split(','))
            new_badges = update_user_stats(current_user, 'portscan', ports_scanned=ports_count)
            results['new_badges'] = new_badges
        
        return jsonify(results)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/osint/reputation', methods=['POST'])
def osint_reputation():
    """Check reputation using OSINT tools"""
    try:
        target = request.form.get('target', '').strip()
        if not target:
            return jsonify({'error': 'Alvo não fornecido'}), 400
        
        results = osint.check_reputation(target)
        return jsonify(results)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
