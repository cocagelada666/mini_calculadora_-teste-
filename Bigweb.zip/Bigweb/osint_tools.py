import whois
import dns.resolver
import ipwhois
import requests
import socket
import ssl
import nmap
import phonenumbers
import logging
from urllib.parse import urlparse
import json
from datetime import datetime
import re
import time
import subprocess
import tempfile
import os
import base64
from exifread import process_file

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class OSINTAnalyzer:
    """Comprehensive OSINT analysis tools"""
    
    def __init__(self):
        self.nm = None  # Initialize nmap scanner only when needed
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })
    
    def analyze_domain(self, domain):
        """Comprehensive domain analysis"""
        results = {
            'domain': domain,
            'timestamp': datetime.now().isoformat(),
            'whois_info': {},
            'dns_records': {},
            'subdomains': [],
            'security_headers': {},
            'ssl_info': {},
            'reputation': {},
            'ip_info': {}
        }
        
        try:
            # WHOIS information
            results['whois_info'] = self._get_whois_info(domain)
            
            # DNS records
            results['dns_records'] = self._get_dns_records(domain)
            
            # IP information
            if results['dns_records'].get('A'):
                ip = results['dns_records']['A'][0]
                results['ip_info'] = self._get_ip_info(ip)
            
            # SSL information
            results['ssl_info'] = self._get_ssl_info(domain)
            
            # Security headers
            results['security_headers'] = self._check_security_headers(domain)
            
            # Basic subdomain enumeration
            results['subdomains'] = self._find_subdomains(domain)
            
        except Exception as e:
            logger.error(f"Error analyzing domain {domain}: {str(e)}")
            results['error'] = str(e)
        
        return results
    
    def _get_whois_info(self, domain):
        """Get WHOIS information for domain"""
        try:
            w = whois.whois(domain)
            return {
                'registrar': w.registrar,
                'creation_date': str(w.creation_date) if w.creation_date else None,
                'expiration_date': str(w.expiration_date) if w.expiration_date else None,
                'updated_date': str(w.updated_date) if w.updated_date else None,
                'name_servers': w.name_servers if w.name_servers else [],
                'emails': w.emails if w.emails else [],
                'org': w.org,
                'country': w.country
            }
        except Exception as e:
            logger.error(f"WHOIS lookup failed for {domain}: {str(e)}")
            return {'error': str(e)}
    
    def _get_dns_records(self, domain):
        """Get DNS records for domain"""
        records = {}
        record_types = ['A', 'AAAA', 'MX', 'NS', 'TXT', 'CNAME', 'SOA']
        
        for record_type in record_types:
            try:
                answers = dns.resolver.resolve(domain, record_type)
                records[record_type] = [str(rdata) for rdata in answers]
            except Exception:
                records[record_type] = []
        
        return records
    
    def _get_ip_info(self, ip):
        """Get IP information using ipwhois"""
        try:
            obj = ipwhois.IPWhois(ip)
            res = obj.lookup_rdap()
            
            return {
                'ip': ip,
                'network': res.get('network', {}),
                'asn': res.get('asn'),
                'asn_description': res.get('asn_description'),
                'asn_country_code': res.get('asn_country_code'),
                'entities': res.get('entities', [])
            }
        except Exception as e:
            logger.error(f"IP lookup failed for {ip}: {str(e)}")
            return {'error': str(e)}
    
    def _get_ssl_info(self, domain):
        """Get SSL certificate information"""
        try:
            context = ssl.create_default_context()
            with socket.create_connection((domain, 443), timeout=10) as sock:
                with context.wrap_socket(sock, server_hostname=domain) as ssock:
                    cert = ssock.getpeercert()
                    
                    return {
                        'issuer': dict(x[0] for x in cert['issuer']),
                        'subject': dict(x[0] for x in cert['subject']),
                        'serial_number': cert.get('serialNumber'),
                        'not_before': cert.get('notBefore'),
                        'not_after': cert.get('notAfter'),
                        'version': cert.get('version'),
                        'signature_algorithm': cert.get('signatureAlgorithm'),
                        'san': cert.get('subjectAltName', [])
                    }
        except Exception as e:
            logger.error(f"SSL check failed for {domain}: {str(e)}")
            return {'error': str(e)}
    
    def _check_security_headers(self, domain):
        """Check security headers"""
        try:
            response = self.session.get(f'https://{domain}', timeout=10)
            headers = response.headers
            
            security_headers = {
                'strict_transport_security': headers.get('Strict-Transport-Security'),
                'content_security_policy': headers.get('Content-Security-Policy'),
                'x_frame_options': headers.get('X-Frame-Options'),
                'x_content_type_options': headers.get('X-Content-Type-Options'),
                'x_xss_protection': headers.get('X-XSS-Protection'),
                'referrer_policy': headers.get('Referrer-Policy'),
                'permissions_policy': headers.get('Permissions-Policy'),
                'server': headers.get('Server'),
                'x_powered_by': headers.get('X-Powered-By')
            }
            
            return security_headers
        except Exception as e:
            logger.error(f"Security headers check failed for {domain}: {str(e)}")
            return {'error': str(e)}
    
    def _find_subdomains(self, domain):
        """Basic subdomain enumeration"""
        subdomains = []
        common_subdomains = [
            'www', 'mail', 'ftp', 'blog', 'www1', 'www2', 'ns1', 'ns2',
            'admin', 'api', 'dev', 'staging', 'test', 'shop', 'forum',
            'help', 'support', 'docs', 'cdn', 'static', 'img', 'images'
        ]
        
        for sub in common_subdomains:
            try:
                subdomain = f"{sub}.{domain}"
                dns.resolver.resolve(subdomain, 'A')
                subdomains.append(subdomain)
            except Exception:
                continue
        
        return subdomains
    
    def analyze_url(self, url):
        """Analyze URL for various information"""
        results = {
            'url': url,
            'timestamp': datetime.now().isoformat(),
            'parsed_url': {},
            'response_info': {},
            'security_headers': {},
            'technologies': [],
            'links': [],
            'forms': [],
            'redirects': []
        }
        
        try:
            # Parse URL
            parsed = urlparse(url)
            results['parsed_url'] = {
                'scheme': parsed.scheme,
                'netloc': parsed.netloc,
                'path': parsed.path,
                'params': parsed.params,
                'query': parsed.query,
                'fragment': parsed.fragment
            }
            
            # Get response information
            response = self.session.get(url, timeout=10, allow_redirects=False)
            results['response_info'] = {
                'status_code': response.status_code,
                'headers': dict(response.headers),
                'content_length': len(response.content),
                'content_type': response.headers.get('content-type')
            }
            
            # Check for redirects
            if response.is_redirect:
                results['redirects'].append({
                    'from': url,
                    'to': response.headers.get('Location'),
                    'status': response.status_code
                })
            
            # Technology detection
            results['technologies'] = self._detect_technologies(response)
            
        except Exception as e:
            logger.error(f"URL analysis failed for {url}: {str(e)}")
            results['error'] = str(e)
        
        return results
    
    def _detect_technologies(self, response):
        """Detect technologies used by the website"""
        technologies = []
        headers = response.headers
        content = response.text.lower()
        
        # Server detection
        server = headers.get('server', '')
        if 'nginx' in server.lower():
            technologies.append('Nginx')
        elif 'apache' in server.lower():
            technologies.append('Apache')
        elif 'iis' in server.lower():
            technologies.append('IIS')
        
        # Framework detection
        if 'x-powered-by' in headers:
            technologies.append(f"Powered by: {headers['x-powered-by']}")
        
        # CMS detection
        if 'wp-content' in content:
            technologies.append('WordPress')
        elif 'joomla' in content:
            technologies.append('Joomla')
        elif 'drupal' in content:
            technologies.append('Drupal')
        
        # JavaScript frameworks
        if 'react' in content:
            technologies.append('React')
        elif 'angular' in content:
            technologies.append('Angular')
        elif 'vue' in content:
            technologies.append('Vue.js')
        
        return technologies
    
    def analyze_phone(self, phone_number, country_code=None):
        """Analyze phone number"""
        try:
            parsed = phonenumbers.parse(phone_number, country_code)
            
            return {
                'number': phone_number,
                'country_code': parsed.country_code,
                'national_number': parsed.national_number,
                'is_valid': phonenumbers.is_valid_number(parsed),
                'is_possible': phonenumbers.is_possible_number(parsed),
                'number_type': phonenumbers.number_type(parsed),
                'carrier': phonenumbers.carrier.name_for_number(parsed, 'en'),
                'geocoder': phonenumbers.geocoder.description_for_number(parsed, 'en'),
                'timezone': phonenumbers.timezone.time_zones_for_number(parsed)
            }
        except Exception as e:
            logger.error(f"Phone analysis failed for {phone_number}: {str(e)}")
            return {'error': str(e)}
    
    def analyze_email(self, email):
        """Basic email analysis"""
        try:
            domain = email.split('@')[1]
            
            return {
                'email': email,
                'domain': domain,
                'domain_analysis': self._get_dns_records(domain),
                'disposable': self._check_disposable_email(domain),
                'mx_records': self._get_mx_records(domain)
            }
        except Exception as e:
            logger.error(f"Email analysis failed for {email}: {str(e)}")
            return {'error': str(e)}
    
    def _check_disposable_email(self, domain):
        """Check if email domain is disposable"""
        disposable_domains = [
            '10minutemail.com', 'tempmail.org', 'guerrillamail.com',
            'mailinator.com', 'trashmail.com', 'yopmail.com'
        ]
        return domain.lower() in disposable_domains
    
    def _get_mx_records(self, domain):
        """Get MX records for email domain"""
        try:
            mx_records = dns.resolver.resolve(domain, 'MX')
            return [{'preference': record.preference, 'exchange': str(record.exchange)} 
                   for record in mx_records]
        except Exception:
            return []
    
    def analyze_image_metadata(self, image_data):
        """Analyze image EXIF data"""
        try:
            # Create temporary file
            with tempfile.NamedTemporaryFile(delete=False) as tmp_file:
                tmp_file.write(image_data)
                tmp_file.flush()
                
                # Process EXIF data
                with open(tmp_file.name, 'rb') as f:
                    tags = process_file(f)
                
                # Clean up
                os.unlink(tmp_file.name)
                
                # Convert tags to dictionary
                exif_data = {}
                for tag in tags.keys():
                    if tag not in ('JPEGThumbnail', 'TIFFThumbnail', 'Filename', 'EXIF MakerNote'):
                        exif_data[tag] = str(tags[tag])
                
                return {
                    'has_exif': bool(exif_data),
                    'exif_data': exif_data,
                    'gps_info': self._extract_gps_info(tags)
                }
        except Exception as e:
            logger.error(f"Image metadata analysis failed: {str(e)}")
            return {'error': str(e)}
    
    def _extract_gps_info(self, tags):
        """Extract GPS information from EXIF tags"""
        gps_info = {}
        
        try:
            if 'GPS GPSLatitude' in tags and 'GPS GPSLongitude' in tags:
                lat = tags['GPS GPSLatitude']
                lon = tags['GPS GPSLongitude']
                lat_ref = tags.get('GPS GPSLatitudeRef', 'N')
                lon_ref = tags.get('GPS GPSLongitudeRef', 'E')
                
                gps_info = {
                    'latitude': str(lat),
                    'longitude': str(lon),
                    'latitude_ref': str(lat_ref),
                    'longitude_ref': str(lon_ref)
                }
        except Exception:
            pass
        
        return gps_info
    
    def port_scan(self, host, ports='22,23,21,20,80,443,8080,8443,8888,3389,5432,3306,1433,5672,6379,9200,9300'):
        """Perform port scan on host"""
        try:
            # Initialize nmap scanner only when needed
            if self.nm is None:
                self.nm = nmap.PortScanner()
            
            self.nm.scan(host, ports)
            results = {
                'host': host,
                'timestamp': datetime.now().isoformat(),
                'state': self.nm[host].state(),
                'protocols': {}
            }
            
            for proto in self.nm[host].all_protocols():
                ports_info = {}
                for port in self.nm[host][proto].keys():
                    port_info = self.nm[host][proto][port]
                    ports_info[port] = {
                        'state': port_info['state'],
                        'name': port_info['name'],
                        'product': port_info.get('product', ''),
                        'version': port_info.get('version', ''),
                        'extrainfo': port_info.get('extrainfo', '')
                    }
                results['protocols'][proto] = ports_info
            
            return results
        except Exception as e:
            logger.error(f"Port scan failed for {host}: {str(e)}")
            return {'error': str(e)}
    
    def check_reputation(self, domain_or_ip):
        """Check reputation using various sources"""
        results = {
            'target': domain_or_ip,
            'timestamp': datetime.now().isoformat(),
            'reputation_sources': {}
        }
        
        # This would integrate with reputation APIs
        # For now, we'll do basic checks
        try:
            # Check if it's an IP or domain
            socket.inet_aton(domain_or_ip)
            is_ip = True
        except socket.error:
            is_ip = False
        
        # Basic reputation checks
        results['reputation_sources']['is_ip'] = is_ip
        results['reputation_sources']['blacklisted'] = self._check_basic_blacklist(domain_or_ip)
        
        return results
    
    def _check_basic_blacklist(self, target):
        """Basic blacklist check"""
        # This is a placeholder - in production, you'd use real blacklist APIs
        suspicious_patterns = [
            'bit.ly', 'tinyurl.com', 'goo.gl', 't.co',
            'malware', 'phishing', 'spam', 'suspicious'
        ]
        
        return any(pattern in target.lower() for pattern in suspicious_patterns)