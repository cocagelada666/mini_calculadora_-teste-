from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
import json

db = SQLAlchemy()

# Association table for user badges (many-to-many)
user_badges = db.Table('user_badges',
    db.Column('user_id', db.Integer, db.ForeignKey('user.id'), primary_key=True),
    db.Column('badge_id', db.Integer, db.ForeignKey('badge.id'), primary_key=True),
    db.Column('earned_at', db.DateTime, default=datetime.utcnow)
)

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    
    # Profile information
    display_name = db.Column(db.String(100), nullable=True)
    bio = db.Column(db.Text, nullable=True)
    location = db.Column(db.String(100), nullable=True)
    website = db.Column(db.String(200), nullable=True)
    avatar_url = db.Column(db.String(500), nullable=True)
    
    # Statistics
    total_investigations = db.Column(db.Integer, default=0)
    total_domains_analyzed = db.Column(db.Integer, default=0)
    total_urls_analyzed = db.Column(db.Integer, default=0)
    total_images_scraped = db.Column(db.Integer, default=0)
    total_ports_scanned = db.Column(db.Integer, default=0)
    
    # Levels and XP
    level = db.Column(db.Integer, default=1)
    experience_points = db.Column(db.Integer, default=0)
    
    # Admin status
    is_admin = db.Column(db.Boolean, default=False)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    badges = db.relationship('Badge', secondary=user_badges, backref='users')
    investigations = db.relationship('Investigation', backref='user', lazy=True)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def add_experience(self, points):
        """Add experience points and check for level up"""
        self.experience_points += points
        
        # Level up calculation (exponential)
        new_level = min(50, int((self.experience_points / 100) ** 0.5) + 1)
        if new_level > self.level:
            self.level = new_level
            return True  # Level up occurred
        return False
    
    def get_level_progress(self):
        """Get progress to next level"""
        current_level_xp = ((self.level - 1) ** 2) * 100
        next_level_xp = (self.level ** 2) * 100
        progress = ((self.experience_points - current_level_xp) / (next_level_xp - current_level_xp)) * 100
        return min(100, max(0, progress))
    
    def check_badges(self):
        """Check and award badges based on user activities"""
        new_badges = []
        
        # Investigation badges
        if self.total_investigations >= 1 and not self.has_badge('first_investigation'):
            new_badges.append('first_investigation')
        if self.total_investigations >= 10 and not self.has_badge('investigator'):
            new_badges.append('investigator')
        if self.total_investigations >= 50 and not self.has_badge('detective'):
            new_badges.append('detective')
        if self.total_investigations >= 100 and not self.has_badge('expert_investigator'):
            new_badges.append('expert_investigator')
        
        # Domain analysis badges
        if self.total_domains_analyzed >= 5 and not self.has_badge('domain_hunter'):
            new_badges.append('domain_hunter')
        if self.total_domains_analyzed >= 25 and not self.has_badge('domain_expert'):
            new_badges.append('domain_expert')
        
        # Image scraping badges
        if self.total_images_scraped >= 100 and not self.has_badge('image_collector'):
            new_badges.append('image_collector')
        if self.total_images_scraped >= 1000 and not self.has_badge('image_master'):
            new_badges.append('image_master')
        
        # Level badges
        if self.level >= 5 and not self.has_badge('level_5'):
            new_badges.append('level_5')
        if self.level >= 10 and not self.has_badge('level_10'):
            new_badges.append('level_10')
        if self.level >= 25 and not self.has_badge('level_25'):
            new_badges.append('level_25')
        
        # Port scanning badges
        if self.total_ports_scanned >= 10 and not self.has_badge('port_scanner'):
            new_badges.append('port_scanner')
        if self.total_ports_scanned >= 100 and not self.has_badge('security_analyst'):
            new_badges.append('security_analyst')
        
        # Award new badges
        for badge_name in new_badges:
            badge = Badge.query.filter_by(name=badge_name).first()
            if badge:
                self.badges.append(badge)
        
        return new_badges
    
    def has_badge(self, badge_name):
        """Check if user has a specific badge"""
        return any(badge.name == badge_name for badge in self.badges)
    
    def get_rank(self):
        """Get user rank based on level"""
        if self.level >= 40:
            return "OSINT Master"
        elif self.level >= 30:
            return "Elite Investigator"
        elif self.level >= 20:
            return "Expert Analyst"
        elif self.level >= 15:
            return "Senior Detective"
        elif self.level >= 10:
            return "Detective"
        elif self.level >= 5:
            return "Investigator"
        else:
            return "Novice"

class Badge(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), unique=True, nullable=False)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    icon = db.Column(db.String(50), nullable=False)  # FontAwesome icon class
    color = db.Column(db.String(20), nullable=False)  # Badge color
    rarity = db.Column(db.String(20), default='common')  # common, rare, epic, legendary
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Investigation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    type = db.Column(db.String(50), nullable=False)  # domain, url, ip, phone, email, portscan
    target = db.Column(db.String(500), nullable=False)
    results = db.Column(db.Text, nullable=True)  # JSON string of results
    status = db.Column(db.String(20), default='completed')  # completed, failed, in_progress
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def set_results(self, results_dict):
        """Store results as JSON string"""
        self.results = json.dumps(results_dict)
    
    def get_results(self):
        """Get results as dictionary"""
        if self.results:
            return json.loads(self.results)
        return {}

class ImageScrapeJob(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    url = db.Column(db.String(500), nullable=False)
    images_found = db.Column(db.Integer, default=0)
    images_downloaded = db.Column(db.Integer, default=0)
    zip_filename = db.Column(db.String(200), nullable=True)
    status = db.Column(db.String(20), default='pending')  # pending, processing, completed, failed
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    completed_at = db.Column(db.DateTime, nullable=True)

def init_badges():
    """Initialize default badges"""
    badges_data = [
        # Investigation badges
        {
            'name': 'first_investigation',
            'title': 'First Investigation',
            'description': 'Complete your first OSINT investigation',
            'icon': 'fas fa-search',
            'color': 'success',
            'rarity': 'common'
        },
        {
            'name': 'investigator',
            'title': 'Investigator',
            'description': 'Complete 10 investigations',
            'icon': 'fas fa-user-secret',
            'color': 'primary',
            'rarity': 'common'
        },
        {
            'name': 'detective',
            'title': 'Detective',
            'description': 'Complete 50 investigations',
            'icon': 'fas fa-eye',
            'color': 'info',
            'rarity': 'rare'
        },
        {
            'name': 'expert_investigator',
            'title': 'Expert Investigator',
            'description': 'Complete 100 investigations',
            'icon': 'fas fa-medal',
            'color': 'warning',
            'rarity': 'epic'
        },
        
        # Domain badges
        {
            'name': 'domain_hunter',
            'title': 'Domain Hunter',
            'description': 'Analyze 5 domains',
            'icon': 'fas fa-globe',
            'color': 'success',
            'rarity': 'common'
        },
        {
            'name': 'domain_expert',
            'title': 'Domain Expert',
            'description': 'Analyze 25 domains',
            'icon': 'fas fa-network-wired',
            'color': 'info',
            'rarity': 'rare'
        },
        
        # Image badges
        {
            'name': 'image_collector',
            'title': 'Image Collector',
            'description': 'Scrape 100 images',
            'icon': 'fas fa-images',
            'color': 'success',
            'rarity': 'common'
        },
        {
            'name': 'image_master',
            'title': 'Image Master',
            'description': 'Scrape 1000 images',
            'icon': 'fas fa-camera',
            'color': 'warning',
            'rarity': 'epic'
        },
        
        # Level badges
        {
            'name': 'level_5',
            'title': 'Rising Star',
            'description': 'Reach level 5',
            'icon': 'fas fa-star',
            'color': 'info',
            'rarity': 'common'
        },
        {
            'name': 'level_10',
            'title': 'Experienced',
            'description': 'Reach level 10',
            'icon': 'fas fa-trophy',
            'color': 'warning',
            'rarity': 'rare'
        },
        {
            'name': 'level_25',
            'title': 'Master',
            'description': 'Reach level 25',
            'icon': 'fas fa-crown',
            'color': 'danger',
            'rarity': 'legendary'
        },
        
        # Security badges
        {
            'name': 'port_scanner',
            'title': 'Port Scanner',
            'description': 'Scan 10 hosts',
            'icon': 'fas fa-shield-alt',
            'color': 'primary',
            'rarity': 'common'
        },
        {
            'name': 'security_analyst',
            'title': 'Security Analyst',
            'description': 'Scan 100 hosts',
            'icon': 'fas fa-user-shield',
            'color': 'danger',
            'rarity': 'rare'
        },
    ]
    
    for badge_data in badges_data:
        existing = Badge.query.filter_by(name=badge_data['name']).first()
        if not existing:
            badge = Badge(**badge_data)
            db.session.add(badge)
    
    db.session.commit()