# Web Image Scraper & OSINT Application

## Overview

This is a Flask-based web application that combines multiple functionalities:
1. **Image Scraper**: Extracts images from web pages and packages them into downloadable ZIP files
2. **OSINT Tools**: Comprehensive Open Source Intelligence tools for analyzing domains, URLs, IPs, phone numbers, emails, and performing port scans
3. **User Profile System**: Social media-style user profiles with badges, levels, and gamification
4. **Administrative Panel**: Admin tools for managing badges and users

Users can create accounts, use OSINT tools with activity tracking, earn badges and XP, and compete in leaderboards.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a simple Flask monolithic architecture pattern:

- **Frontend**: HTML templates with Bootstrap for styling
- **Backend**: Python Flask web framework
- **File Management**: Local file system storage with temporary directories
- **Web Scraping**: BeautifulSoup for HTML parsing and requests for HTTP operations
- **Deployment**: Configured for hosting on platforms like Replit

## Key Components

### 1. Flask Application (`app.py`)
- **Purpose**: Main application logic and routing
- **Key Features**:
  - URL validation and image detection
  - Web scraping functionality using BeautifulSoup
  - Image downloading with proper headers
  - ZIP file creation for batch downloads
  - User authentication system (login, register, logout)
  - Session management and flash messaging
  - OSINT tools integration with comprehensive analysis endpoints
  - User activity tracking and badge system
  - Administrative panel for managing badges and users

### 2. Database Models (`models.py`)
- **Purpose**: Database schema and user management
- **Key Features**:
  - User model with authentication, profiles, and statistics
  - Badge system with rarities and conditions
  - Investigation tracking for all OSINT activities
  - Image scraping job history
  - User-badge relationships and experience system
  - Administrative privileges and user roles

### 3. OSINT Tools (`osint_tools.py`)
- **Purpose**: Open Source Intelligence gathering and analysis
- **Key Features**:
  - Domain analysis (WHOIS, DNS, SSL, security headers, subdomains)
  - URL analysis (HTTP headers, technologies, redirects)
  - IP address investigation (geolocation, ASN, network info)
  - Phone number validation and analysis
  - Email domain verification and MX records
  - Port scanning capabilities
  - Image metadata extraction (EXIF data, GPS info)
  - Basic reputation checking

### 4. Entry Point (`main.py`)
- **Purpose**: Application startup configuration
- **Configuration**: Runs on host `0.0.0.0:5000` with debug mode enabled

### 3. Frontend Templates
- **`templates/index.html`**: Main image scraper interface
  - Bootstrap-based responsive design with dark theme
  - URL input form for web scraping
  - Download interface for ZIP files
  - Navigation to OSINT tools
  
- **`templates/osint.html`**: OSINT tools interface
  - Tabbed interface for different analysis types
  - Real-time results display with JSON formatting
  - Interactive forms with validation
  - Loading states and error handling
  - Portuguese language support

### 4. Static Assets (`static/style.css`)
- **Purpose**: Custom styling and visual enhancements
- **Features**:
  - Gradient backgrounds and modern UI elements
  - Custom button hover effects
  - Card-based layout with backdrop blur effects
  - Responsive design considerations

## Data Flow

1. **User Input**: User enters a URL through the web interface
2. **Validation**: Application validates URL format and accessibility
3. **Web Scraping**: BeautifulSoup parses HTML and extracts image URLs
4. **Image Processing**: Application filters and validates image URLs
5. **Download**: Images are downloaded to temporary directories
6. **ZIP Creation**: Downloaded images are packaged into a ZIP file
7. **File Delivery**: ZIP file is served to user for download
8. **Cleanup**: Temporary files and directories are cleaned up

## External Dependencies

### Python Libraries
- **Flask**: Web framework for handling HTTP requests and responses
- **requests**: HTTP library for downloading web content and images
- **BeautifulSoup**: HTML parsing library for extracting image URLs
- **werkzeug**: WSGI utilities including ProxyFix for deployment
- **python-whois**: Domain WHOIS information retrieval
- **dnspython**: DNS record queries and analysis
- **ipwhois**: IP address WHOIS and geolocation information
- **phonenumbers**: Phone number validation and analysis
- **python-nmap**: Port scanning capabilities
- **shodan**: Internet device search engine integration
- **ExifRead**: Image metadata extraction

### Frontend Dependencies
- **Bootstrap**: CSS framework for responsive design (CDN-hosted)
- **FontAwesome**: Icon library for UI enhancements (CDN-hosted)
- **Custom CSS**: Additional styling for enhanced user experience

### System Dependencies
- **tempfile**: For creating temporary directories during processing
- **zipfile**: For creating downloadable ZIP archives
- **urllib.parse**: For URL validation and manipulation
- **uuid**: For generating unique identifiers
- **shutil**: For file operations and cleanup

## Deployment Strategy

The application is configured for deployment on cloud platforms:

- **Host Configuration**: Binds to `0.0.0.0:5000` for external access
- **Proxy Support**: Uses ProxyFix middleware for proper header handling behind proxies
- **Environment Variables**: Uses `SESSION_SECRET` for session management with fallback
- **Static File Serving**: Flask serves static assets directly
- **Error Handling**: Comprehensive logging and user-friendly error messages
- **File Management**: Automatic cleanup of temporary files and directories

### Key Deployment Considerations
- **Security**: Session secret should be set via environment variables
- **Performance**: Image downloads are handled synchronously (could be optimized for concurrent processing)
- **Storage**: Uses local file system storage (suitable for single-instance deployments)
- **Scalability**: Current architecture is designed for single-instance deployment